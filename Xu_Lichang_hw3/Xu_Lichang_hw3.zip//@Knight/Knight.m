classdef Knight < ChessPiece
    %%PAWN is a subclass of ChessPiece.
    %   It inherits all properties of its upperclass.
    %   It implements getSymbol(chesspiece) method specific to Knight.
    
    properties
    end
    
    methods
        function obj = Knight(position,board,teamnumber)
            obj = obj@ChessPiece(position,board,teamnumber); % Call upperclass constructor
        end
        
        function symbol = getSymbol(chesspiece)
            symbol = 'N';
        end
    end
    
end