classdef (Abstract) ChessPiece < handle
    %%CHESSPIECE is an abstract handle class.
    %   It holds methods and properties common to each of the chess pieces.
    %   It has two properties as described in the following:
    %   Position is a 1x2 double array of the x and y coordinates
    %   Team is either 1 or 2 for which team the piece belongs to
    %   It has three methods as described in the following:
    %   getSymbol(chesspiece) is an abstract method that returns the symbol
    %   (a single uppercase character) of the given chess piece.
    
    properties 
        Position = []; % a 1x2 double array of the x and y coordinates
        Team; % should be either 1 or 2 for which team the piece belongs to
    end
    
    methods
        function obj = ChessPiece(position,board,teamnumber) % Constructor
            % Check inputs
            if((~isa(position,'double')) || (numel(position) ~= 2))
                error('position must be a 1x2 double array.');
            end
            if((~isa(teamnumber,'double')) || ((teamnumber ~= 1) && (teamnumber ~= 2)))
                error('teamnumber must be a valid number (either 1 or 2).');
            end
            % Set properties
            obj.Position = position;
            obj.Team = teamnumber;
            % Add the piece to the chessboard
            board.addPiece(obj);
        end
    end
    
    methods(Abstract = true)
        symbol = getSymbol(chesspiece); % an abstract class needed to implement
    end
        
end
        