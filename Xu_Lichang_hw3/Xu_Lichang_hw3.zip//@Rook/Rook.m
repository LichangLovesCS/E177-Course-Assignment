classdef Rook < ChessPiece
    %%ROOk is a subclass of ChessPiece.
    %   It inherits all properties of its upperclass.
    %   It implements getSymbol(chesspiece) method specific to Rook.
    
    properties
    end
    
    methods
        function obj = Rook(position,board,teamnumber)
            obj = obj@ChessPiece(position,board,teamnumber); % Call upperclass constructor
        end
        
        function symbol = getSymbol(chesspiece)
            symbol = 'R';
        end
    end
    
end