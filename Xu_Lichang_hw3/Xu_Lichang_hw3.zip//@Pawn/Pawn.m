classdef Pawn < ChessPiece
    %%PAWN is a subclass of ChessPiece.
    %   It inherits all properties of its upperclass.
    %   It implements getSymbol(chesspiece) method specific to Pawn.
    
    properties
    end
    
    methods
        function obj = Pawn(position,board,teamnumber)
            obj = obj@ChessPiece(position,board,teamnumber); % Call superclass constructor
        end
            
        function symbol = getSymbol(chesspiece)
            symbol = 'P';
        end
    end
    
end