classdef King < ChessPiece
    %%KING is a subclass of ChessPiece.
    %   It inherits all properties of its upperclass.
    %   It implements getSymbol(chesspiece) method specific to King.
    %   It has a different constructor from its upperclass.
    
    properties
    end
    
    methods
        function obj = King(position,board,teamnumber,chessgame) % Different constructor
            obj = obj@ChessPiece(position,board,teamnumber); % Just for now
        end
                  
        function symbol = getSymbol(chesspiece)
            symbol = 'K';
        end
    end
    
end